const firstname = document.getElementById("firstname");
const surname = document.getElementById("surname");
const dropDown = document.getElementById("drop-down");
const dial = document.getElementById("dial")
const countryCodes = ["+234","+233","+44","+1","+77"]

// countryCodes.forEach((data,index)=>{
//     dropDown.innerHTML += `<option id=${index} >${data}</option>`
// })

for (let index = 0; index < countryCodes.length; index++) {
    dropDown.innerHTML += `<option id=${index} >${countryCodes[index]}</option>`
}

firstname.addEventListener("keyup",function(e){
    validateName(firstname)
})

function validateName(field){
    const name = field.value
    if(name.length<2){
        console.log("can't be less than 2 chars")
        updateElementStyle(field,"invalid")
        return
    }
    updateElementStyle(field,"valid")
}

function updateElementStyle(field,action){
    if(action=="valid"){
        field.style.borderWidth = "3px"
        field.style.borderColor = "green"
        console.log("valid")
        return
    }
    field.style.borderWidth = "3px"
    field.style.borderColor = "red"

}

surname.addEventListener("keyup",function(e){
    validateName(surname)
})

dial.addEventListener("keyup",function(e){
    const phone = dial.value
    if(phone.length==10){
        updateElementStyle(dial,"valid")
        return
    }
    updateElementStyle(dial,"invalid")
})